<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome_model extends CI_Model {

public function __construct()
        {
                parent::__construct();
                // Your own constructor code

               $this->load->database();
        }

function getall_list()
{
	return $this->db->query("SELECT * FROM to_do_list");
}

function savetask($data)
{
	$this->db->insert("to_do_list",$data);
}
function updatetask($data,$where)
{
	$this->db->where($where);
	$this->db->update("to_do_list",$data);
}
}