<?php ?>
<!DOCTYPE html>
<html>
<head>
	<title>To DOs</title>
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<center><h2>To dos</h2></center>
	<hr>
<div class="row text-center" style="margin:10px">
	<div class="col-lg-4">
	
				<div style="width:80%">
					<u><h3>Add Task</h3></u>
				    <div class="form-group">
				      <label for="title">Title:</label>
				      <input type="text" class="form-control" id="title" placeholder="Enter Task Title">
				    </div>
				    <div class="form-group">
				      <label for="desc">Description:</label>
				       <textarea class="form-control" rows="5" id="desc"></textarea>
				      
				    </div>
				   
				    <button type="button" class="btn btn-default" onclick="create_task()">Submit</button>
				  </div>
			
	</div>


		<div class="col-lg-8">	
			<u><h3>View/Edit Task</h3></u>
			<div class="table-responsive" style="margin-top:40px">
		<table class="table">
			<tr>
				<th>Sl.no</th>
				<th>Title</th>
				<th>Description</th>
				<th>Status</th>
				<th>Created On</th>
				<th>Closed On</th>
				<th>Change status</th>
			</tr>
			<?=$data_table?>
		</table>
	</div></div>

		
		

	
	
</div>
<script type="text/javascript">
	function create_task()
	{

		var title=$("#title").val();
		var desc=$("#desc").val();
		
		if(title=="" || desc=="")
		{
			alert("enter title and desc");
			return false;
			
		}
		var url="<?=base_url()?>index.php/welcome/create_task";
		$.ajax({
			type:"POST",
			data:{title:title,desc:desc},
			dataType:"JSON",
			url:url,
			success: function(data)
			{
				window.location.reload();
			}
		});
	}

	function change_status(id)
	{
		var action=$("#action_"+id).val();
		if(action=="")
		{
			return false;
		}
			var url="<?=base_url()?>index.php/welcome/update_task";
		$.ajax({
			type:"POST",
			data:{id:id,action:action},
			dataType:"JSON",
			url:url,
			success: function(data)
			{
								window.location.reload();

			}
		});

	}
</script>
</body>
</html>