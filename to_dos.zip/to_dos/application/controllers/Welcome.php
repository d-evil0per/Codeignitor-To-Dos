<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


	public function __construct()
        {
                parent::__construct();
                // Your own constructor code

                $this->load->model("welcome_model");
        }
	public function index()
	{

		$to_do_list=$this->welcome_model->getall_list();
		$data_table="";
		foreach ($to_do_list->result() as $list) {

			$status=$list->to_do_list_status;
			switch ($status) {
				case 1:
					$status_code="<span style='color:blue'>Allocated</span>";
					break;
				case 2:
					$status_code="<span style='color:orange'>In Progress</span";
					break;
				case 3:
					$status_code="<span style='color:green'>Completed</span";
					break;
			}
			if($list->to_do_list_closed=="0000-00-00 00:00:00")
			{
				$closed_date="-";
			}
			else
			{
				$closed_date=date("d M", strtotime($list->to_do_list_closed));
			}
			$data_table.="<tr>";
			$data_table.="<td>".$list->to_do_list_id."</td>";
			$data_table.="<td>".$list->to_do_list_title."</td>";
			$data_table.="<td>".$list->to_do_list_desc."</td>";
			$data_table.="<td>".$status_code."</td>";
			$data_table.="<td>".date("d M", strtotime($list->to_do_list_creation))."</td>";
			$data_table.="<td>".$closed_date."</td>";
			$data_table.="<td><select onchange='change_status(".$list->to_do_list_id.")' id='action_".$list->to_do_list_id."'>
			<option value=''>Select Status</option><option value='1'>Allocated</option><option value='2'>In Progress</option><option value='3'>Completed</option></select></td>";
			$data_table.="</tr>";
		}
		$res=array("data_table"=>$data_table);
		$this->load->view('to_dos',$res);
	}
	 function create_task()
	{
		$title=$_POST['title'];
		$desc=$_POST['desc'];
		$data_insert = array('to_do_list_title' =>$title ,'to_do_list_desc' =>$desc ,'to_do_list_status' =>1 , 'to_do_list_creation' =>date("Y-m-d") );
		$this->welcome_model->savetask($data_insert);
		$res['status']="Success";
		echo json_encode($res);
	}
	function update_task()
	{
		$id=$_POST['id'];
		$action=$_POST['action'];
		if($action==3)
		{
			$data_insert = array('to_do_list_status' =>$action , 'to_do_list_closed' =>date("Y-m-d") );
		}
		else
		{
			$data_insert = array('to_do_list_status' =>$action );
		}
		
		$where['to_do_list_id']=$id;
		$this->welcome_model->updatetask($data_insert,$where);
		$res['status']="Success";
		echo json_encode($res);
	}
}
